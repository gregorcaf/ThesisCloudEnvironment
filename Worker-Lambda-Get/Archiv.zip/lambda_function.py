import json
import boto3
import pandas as pd
import grpc
from Proto import master_pb2_grpc
from Proto import master_pb2

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    bucket_name = event["data_bucket_name"]
    filename = event["filename"]

    # read keys (testing purposes)
    obj = s3_client.get_object(Bucket=bucket_name, Key=filename)
    df = pd.read_csv(obj['Body'])
    df.columns = ["date_time"]

    ip_address = "0.tcp.eu.ngrok.io:11276"

    # create a channel
    channel = grpc.insecure_channel(ip_address)

    # create a stub
    stub = master_pb2_grpc.masterStub(channel)

    rows = []

    # for i in range(len(df)):
    #     key = df.iloc[i]["date_time"]

    request = master_pb2.GetDataRequest(key="continent")

    print(request["value"])


    



