import json
# import boto3
import math
import grpc
from Proto import master_pb2_grpc
from Proto import master_pb2

def lambda_handler(event, context):
    bucket_name = event["data_bucket_name"]
    filenames = event["filenames"]

    print("Bucket name: {}".format(bucket_name))
    print("Filenames {}".format(filenames))

    ip_address = "https://a25c-138-246-3-198.ngrok-free.app"
    port = "9090"

    # create a channel
    channel = grpc.insecure_channel("{}:{}".format(ip_address, port))

    # create a stub
    stub = master_pb2_grpc.masterStub(channel)

    # create request object
    request = master_pb2.PutDataRequest(key=bucket_name, value=filenames)

    # make gRPC call
    response = stub.putData(request)

    print(response)


lambda_handler(event = {"data_bucket_name": "Halo", "filenames": "Serbus"})